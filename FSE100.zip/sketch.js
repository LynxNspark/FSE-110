let memImage;
let blockImage;
let towerImage;
let State;
//memgame
var imageCollection={};
  var imagePaths={};
  let animals=[];
  
  let bison; let camel; let croc; let elephant; let giraffe; let gorilla; let hedgehog; let jellyfish; let ladybug; let monkey; let pufferfish; let ram; let rhino; let sauropod; let shark; let skunk; let tiger; let trex; let wood; 
  
  let b2x4; let b3x4; let b4x4; let b4x5; let b3x3; let b5x6; let b6x6; let b6x7;
  
  let rectangles=[];
  
  var tries=0;
  var rows;
  var numRow;
  var columns;
  var numCol;
  let animalList=[];
  let cardList=[];
  var rectWidth;
  var rectHeight;
  var programPaused=false;
  var score=0
  var card1=true;
  var card2=false;
  var firstCard;
  var cardx;
  var cardy;
  var cardx1;
  var cardy1;

  //tower
const blockWidth = 700;
const blockHeight = 70;
let currentBlock;
let placedBlocks = []; // stores previous blocks
let speed = 5;
let direction = 1;

var winSound;

const playing = "playing";
const lose = "lose";
const win = "win";
let gameState = playing;

//block game
let board = [];
let cols, rows2;
let blockSize = 40;
let currentPiece;
let gameOver = false;
let moveSpeedMultiplier = 1.5;

function preload() {
  memImage = loadImage('MemoryGame.PNG');
  blockImage = loadImage('BlockGame.PNG');
  towerImage = loadImage('TowerStack.PNG');
  animals[0]='Pngs/bat.png';
  animals[1]='Pngs/beaver.png';
  animals[2]='Pngs/bee.png';
  animals[3]='Pngs/bison.png';
  animals[4]='Pngs/camel.png';
  animals[5]='Pngs/croc.png';
  animals[6]='Pngs/ladybug.png';
  animals[7]='Pngs/monkey.png';
  animals[8]='Pngs/pufferfish.png';
  animals[9]='Pngs/ram.png';
  animals[10]='Pngs/rhino.png';
  animals[11]='Pngs/sauropod.png';
  animals[12]='Pngs/shark.png';
  animals[13]='Pngs/skunk.png';
  animals[14]='Pngs/tiger.png';
  animals[15]='Pngs/trex.png';
  animals[16]='Pngs/jellyfish.png';
  animals[17]='Pngs/elephant.png';
  animals[18]='Pngs/giraffe.png';
  animals[19]='Pngs/gorilla.png';
  animals[20]='Pngs/hedgehog.png';
  wood = loadImage('Pngs/wood.png');
}

function setup() {
  //canvas
  //if (gameState == "menu") {
  createCanvas(400, 700);
  background('pink');
  textSize(32);
  fill('blue');
  text('Toddler Time', 100, 100);


  //images
  memImage.resize(0, 100);
  blockImage.resize(0, 100);
  towerImage.resize(0, 100);

  image(towerImage, 150 ,400);
  image(blockImage, 150, 550);
  image(memImage, 150 , 250);


  //Buttons
  buttonMem = createButton("Memory Game")
  buttonMem.position(150,350)
  buttonMem.mousePressed(goToMem);

  buttonTower = createButton("Tower Game")
  buttonTower.position(150,500)
  buttonTower.mousePressed(goToTower);

  buttonBlock = createButton("Block Game")
  buttonBlock.position(150,650)
  buttonBlock.mousePressed(goToBlock);
 // }
}

function goToMem() {
  //remove();
  State = "mem"
  //setup();
  buttonBlock.remove();
  buttonMem.remove();
  buttonTower.remove();
  textSize(30);
  image (wood,0,0,400,700);
  drawUI();
  
  function drawUI(){
    fill('black');
    rect(50,100,300,500);
    fill('gold');
    text('Select a Level', 100, 150);
    
  backButton = createButton("Menu");
  backButton.position(0, 675);
  backButton.mousePressed(goToMenu);
    
  b2x4 = createButton('2x3');
  b2x4.position(100,200);
  b2x4.size(75,50);
  b2x4.mousePressed(setCards5);
  
  b3x4 = createButton('3x4');
  b3x4.position(100, 300);
  b3x4.size(75,50);
  b3x4.mousePressed(setCards2);
  
  b4x4 = createButton('4x4');
  b4x4.position(225, 300);
  b4x4.size(75,50);
  b4x4.mousePressed(setCards3);
  
  b4x5 = createButton('4x5');
  b4x5.position(100, 400);
  b4x5.size(75,50);  
  b4x5.mousePressed(setCards4);
    
  b3x3 = createButton('2x4');
  b3x3.position(225, 200);
  b3x3.size(75, 50);
  b3x3.mousePressed(setCards1);
  
  b5x6 = createButton('5x6');
  b5x6.position(225, 400);
  b5x6.size(75, 50);
  b5x6.mousePressed(setCards6);
  
  b6x6 = createButton('6x6');
  b6x6.position(100, 500);
  b6x6.size(75, 50);
  b6x6.mousePressed(setCards7);
  
  b6x7 = createButton('6x7');
  b6x7.position(225, 500);
  b6x7.size(75, 50);
  b6x7.mousePressed(setCards8);
  
  }
}

function goToTower() {
  State = "tower"
  buttonBlock.remove();
  buttonMem.remove();
  buttonTower.remove();
  backButton = createButton("Menu");
  backButton.position(0, 675);
  backButton.mousePressed(goToMenu);
  createCanvas(1470,800);
  textSize(20);
  newGame();
}

function goToBlock() {
  State = "block"
  buttonBlock.remove();
  buttonMem.remove();
  buttonTower.remove();
  backButton = createButton("Menu");
  backButton.position(0, 675);
  backButton.mousePressed(goToMenu);
  createCanvas(400, 700);
  cols = floor(width / blockSize);
  rows2 = floor(height / blockSize);
  initializeBoard();
  spawnNewPiece();
}

//memory game fucntions
function mouseClicked() {
  if(programPaused==false){
  for (let i = 0; i < rectangles.length; i++) {
    let rect1 = rectangles[i];
    if (mouseX > rect1.x && mouseX < rect1.x + rect1.w && mouseY > rect1.y && mouseY < rect1.y + rect1.h) {
      fill('white');
      rect(rect1.x,rect1.y,rect1.w,rect1.h);
      if (true){
      image(cardList[i], rect1.x+5, rect1.y,rect1.w-10,rect1.h-10);
      console.log(i);
      cardsFlipped(i);
      }
    }
  }}
}

function cardsFlipped(num){
  if(card1==true){
    firstCard=cardList[num];
    card1=false;
    card2=true;
    let cardIndex1=num;
    cardx=rectangles[num].x;
    cardy=rectangles[num].y;
  }
  else if(card2==true){
    cardx1=rectangles[num].x;
    cardy1=rectangles[num].y;
    if(firstCard==cardList[num]){
      console.log("success");
      card1=true;
      card2=false;
      score++;
      tries++;
    }
    else{
      console.log("failure");
      card1=true;
      card2=false;
      tries++;
      programPaused=true;
      setTimeout(resetCards,1000);
      programPaused=false;
    }
  }
}

function resetCards(num1,num2){
  fill(colorVar);
  rect(cardx,cardy,rectWidth, rectHeight);
  rect(cardx1,cardy1,rectWidth, rectHeight);
}

function startGame(){
  image (wood,0,0,400,700);
  b2x4.remove();
  b3x4.remove();
  b4x4.remove();
  b4x5.remove();
  b3x3.remove();
  b5x6.remove();
  b6x6.remove();
  b6x7.remove();
  assignCards();
  colorVar=color(random(255),random(255),random(255));
    for (let i=0;i<rows;i++){
    for (let j=0;j<columns;j++){
      drawCards(i,j);
    }
   }
  }

  function assignCards(){
    var numTiles = rows*columns;
    shuffle(animals,true);
    for (let i=0;i<(rows*columns/2);i++){
      var number=int(random(21));
      cardList[i]=loadImage(animals.shift());
    }
    let arraySize = cardList.length;
    for (let j=0;j<arraySize;j++){
      cardList[arraySize+j]=cardList[j];
    }
    shuffle(cardList,true);
  }

  function drawCards(row,column){
    for (let i = 0; i < 1; i++) {
      var rectX = (350/rows)*row+40;
      var rectY = (600/columns)*column+50;
      rectWidth = 500/(rows*2);
      rectHeight = 1000/(columns*2);
      rectangles.push({ x: rectX, y: rectY, w: rectWidth, h: rectHeight });
      fill (colorVar);
        for (let rec of rectangles) {
      rect(rec.x, rec.y, rec.w, rec.h);
    }
    }
  }

  function setCards1(){
    rows=2;
    columns=4;
    startGame();
  }
  
  function setCards2(){
    rows=3;
    columns=4;
    startGame();
  }
  
  function setCards3(){
    rows=4;
    columns=4;
    startGame();
  }
  
  function setCards4(){
    rows=4;
    columns=5;
    startGame();
  }
  
  function setCards5(){
    rows=2;
    columns=3;
    startGame();
  }
  
  function setCards6(){
    rows=5;
    columns=6;
    startGame();
  }
  
  function setCards7(){
    rows=6;
    columns=6;
    startGame();
  }
  
  function setCards8(){
    rows=6;
    columns=7;
    startGame();
  }

  function draw() {
    if(State == "mem") {
    winCondition();
    }
    if(State == "tower") {
      background(220);
  if (gameState === playing) {
    fill(220)
    rect(50,50,100,100);
    drawBlock();
    updateBlock();
  }
  else if (gameState === win) {
    textAlign(CENTER,CENTER);
    fill(0);
    text("You Win", width / 2, height / 2);
  }
  else if (gameState === lose) {
    textAlign(CENTER,CENTER);
    fill(0);
    text("You Lose", width / 2, height / 2);
  }
    }
    if(State == "block") {
      background(220);

  if (gameOver) {
    displayGameOverScreen();
  } else {
    updateBoard();
    drawBoard();
    drawPiece();
  }
    }
   }

   function winCondition(){
    if (score==rows2*columns/2){
    image (wood,0,0,400,700);
     fill('gold');
   rect(50,100,300,500);
    fill('black');
    text('You Win!', 150, 250);
    text(("Tries: "+str(tries)),150,350);
  }
 }

 function goToMenu() {
  State = "null";
  removeElements(); 
  setup(); 
}

//tower functions 
function drawBlock() {
  fill(173,216,230);
  rect(currentBlock.x, currentBlock.y, currentBlock.z, blockHeight); // draws current block
  fill(50);
  for (let block of placedBlocks) {
    rect(block.x, block.y, block.z, blockHeight); // draws previous blocks
  }
  text(placedBlocks.length, 100, 100);
}

function updateBlock() { // moves block back and forth, changing direction at each end of the canvas
  currentBlock.x += speed * direction;
  if(currentBlock.x < 0) {
    direction = 1;
  }
  if (currentBlock.x + currentBlock.z > width) {
    direction = -1;
  }
}

function stopBlock() { // places block 
  const prevBlock = placedBlocks[placedBlocks.length - 1];
  let newWidth = blockWidth;
  if (prevBlock) {
    const left = max(prevBlock.x, currentBlock.x);
    const right = min(prevBlock.x + prevBlock.z, currentBlock.x + currentBlock.z);
    newWidth = right - left;
    currentBlock.z = newWidth;
    currentBlock.x = left;
  }
  if (newWidth < 0) {
    gameState = lose;
    return;
  }
  placedBlocks.push(currentBlock);
  speed *= 1.2;
  nextBlock(newWidth);
}

function nextBlock(newWidth) {
  const blockStackHeight = (placedBlocks.length + 1) * blockHeight;
  if (blockStackHeight > height + blockHeight) {
    gameState = win;
    winSound.play();
    return;
  }
  currentBlock = createVector(0, height - blockStackHeight, newWidth);
}

function keyPressed() {
  if(State == "tower") {
  if (key === " ") {
    if (gameState === playing) {
      stopBlock();
    }
    else if (gameState === win) {
      newGame();
      gameState = playing;
    }
    else if (gameState === lose) {
      newGame();
      gameState = playing;
    }
  }
}
if(State == "block") {
  if (keyCode === LEFT_ARROW) {
    movePiece(-1);
  } else if (keyCode === RIGHT_ARROW) {
    movePiece(1);
  } else if (keyCode === DOWN_ARROW) {
    movePiece(0, 1);
  } else if (keyCode === UP_ARROW) {
    rotatePiece();
  }
}
}

function newGame() {
  currentBlock = createVector(0, height - blockHeight, blockWidth);
  speed = 5;
  direction = 1;

  placedBlocks = [];
}

// block game
function movePiece(xOffset, yOffset = 0) {
  if (isValidMove(currentPiece, xOffset, yOffset)) {
    currentPiece.x += xOffset;
    currentPiece.y += yOffset;
    return true;
  }
  return false;
}

function rotatePiece() {
  let rotatedPiece = rotateMatrix(currentPiece.shape);
  if (isValidMove({ ...currentPiece, shape: rotatedPiece }, 0, 0)) {
    currentPiece.shape = rotatedPiece;
  }
}

function rotateMatrix(matrix) {
  const rows2 = matrix.length;
  const cols = matrix[0].length;
  const result = new Array(cols).fill().map(() => new Array(rows2).fill(0));

  for (let i = 0; i < rows2; i++) {
    for (let j = 0; j < cols; j++) {
      result[j][rows2 - 1 - i] = matrix[i][j];
    }
  }

  return result;
}

function isValidMove(piece, xOffset, yOffset) {
  for (let i = 0; i < piece.shape.length; i++) {
    for (let j = 0; j < piece.shape[i].length; j++) {
      if (
        piece.shape[i][j] &&
        ((board[piece.y + i + yOffset] && board[piece.y + i + yOffset][piece.x + j + xOffset]) !== undefined ||
          piece.x + j + xOffset < 0 ||
          piece.x + j + xOffset >= cols ||
          piece.y + i + yOffset >= rows2)
      ) {
        return false;
      }
    }
  }
  return true;
}

function updateBoard() {
  if (frameCount % (30 / moveSpeedMultiplier) === 0) {
    if (!movePiece(0, 1)) {
      placePiece();
      clearLines();
      spawnNewPiece();
    }
  }
}

function placePiece() {
  for (let i = 0; i < currentPiece.shape.length; i++) {
    for (let j = 0; j < currentPiece.shape[i].length; j++) {
      if (currentPiece.shape[i][j]) {
        board[currentPiece.y + i][currentPiece.x + j] = currentPiece.color;
      }
    }
  }
  checkGameOver();
}

function clearLines() {
  for (let i = rows2 - 1; i >= 0; i--) {
    if (board[i].every((cell) => cell !== undefined)) {
      board.splice(i, 1);
      board.unshift(new Array(cols).fill(undefined));
    }
  }
}

function drawBoard() {
  for (let i = 0; i < rows2; i++) {
    for (let j = 0; j < cols; j++) {
      if (board[i][j] !== undefined) {
        fill(board[i][j]);
        stroke(0);
        rect(j * blockSize, i * blockSize, blockSize, blockSize);
      }
    }
  }
}

function drawPiece() {
  for (let i = 0; i < currentPiece.shape.length; i++) {
    for (let j = 0; j < currentPiece.shape[i].length; j++) {
      if (currentPiece.shape[i][j]) {
        fill(currentPiece.color);
        stroke(0);
        rect((currentPiece.x + j) * blockSize, (currentPiece.y + i) * blockSize, blockSize, blockSize);
      }
    }
  }
}

function spawnNewPiece() {
  const pieces = [
    { shape: [[1, 1, 1, 1]], color: color(255, 0, 0) },
    { shape: [[1, 1], [1, 1]], color: color(0, 255, 0) },
    { shape: [[1, 1, 1], [1, 0, 0]], color: color(0, 0, 255) },
    { shape: [[1, 1, 1], [0, 0, 1]], color: color(255, 255, 0) },
    { shape: [[1, 1], [1, 1]], color: color(0, 0, 255) }, // 2x2 block
    { shape: [[0, 1, 0], [1, 1, 1]], color: color(255, 0, 255) }, // T-shape block
  ];
  currentPiece = random(pieces);
  currentPiece.x = floor(cols / 2) - floor(currentPiece.shape[0].length / 2);
  currentPiece.y = 0;
}

function initializeBoard() {
  for (let i = 0; i < rows2; i++) {
    board.push(new Array(cols).fill(undefined));
  }
}

function displayGameOverScreen() {
  fill(0);
  textSize(30);
  text("Game Over", width / 2 - 80, height / 2 - 20);
  textSize(20);
  text("Press 'R' to restart", width / 2 - 120, height / 2 + 20);
}

function resetGame() {
  initializeBoard();
  spawnNewPiece();
  gameOver = false;
}

function checkGameOver() {
  if (currentPiece.y <= 0) {
    gameOver = true;
  }
}
